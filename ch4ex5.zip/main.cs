using System;
class Range
{
    int counter=0;
    Console.WriteLine("Please enter the first number:");
    int a = int.Parse(Console.ReadLine());
    Console.WriteLine("Pleae e nter the second number:");
    int b = int.Parse(Console.RewadLine());
    
    for (int i=a, i<=a, i++)
       {
           if (i%5==0) counter++;
       }
    Console.WriteLine("{0}, numbers found.", counter);
}