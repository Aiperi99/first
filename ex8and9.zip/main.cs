using System;
namespace Program
{
    public class Phone
	{
		string model;
	    string manufacturer;
		double price;
		string owner;
        string color;
	    
	    public static int countObjects;	
        public string Model
		{
			get { return model;  }
			set { model = value; }
		}
		
		public string Manufacturer
		{
			get { return manufacturer;  }
			set { manufacturer = value; }
		}
        
        public double Price
		{
			get { return price;  }
			set { price = value; }
		}
		
		public string Owner
		{
			get { return owner;  }
			set { owner = value; }
		}
		
		public string Color
		{
			get { return color;  }
			set { color = value; }
		}
		
		public Phone(string mod, string manuf, double pr, string ow, string clr) 
        {
            this.Model = mod;
            this.Manufacturer = manuf;
            this.Price = pr;
            this.Owner = ow;
            this.Color = clr;
            Phone.countObjects++;
        }
        
        public Phone(string mod, string manuf, double pr) 
        {
            this.Model = mod;
            this.Manufacturer = manuf;
            this.Price = pr;
            this.Owner = null;
            this.Color = null;
            Phone.countObjects++;
        }
        
        public Phone(string mod, string manuf, string clr) 
        {
            this.Model = mod;
            this.Manufacturer = manuf;
            this.Price = 0.0;
            this.Owner = null;
            this.Color = clr;
            Phone.countObjects++;
        }
        
        public void showInfo()
        {
            Console.WriteLine("The phone is: {0} {1}.", Manufacturer, Model);
            Console.WriteLine("The price is: {0}. Color is {1}.", Price, Color);
            Console.WriteLine("And it belongs to: {0}.", Owner);
            Console.WriteLine("~~~~~~~~~~~~~~~~~~");
        }
	}
    public class Program
    {
        public static void Main (string []args)
        {
            Phone thephoneIWant = new Phone("J4", "Samsung",800, "me", "gold");
            thephoneIWant.showInfo();
            
            Phone myPhone = new Phone ("XS", "iPhone",3500);
            myPhone.showInfo();
            
            Phone aPhone = new Phone("A20", "Xiaomi", "white");
            aPhone.showInfo();
            
            Console.WriteLine("We have {0} phones here.", Phone.countObjects);
        }
    }	
}