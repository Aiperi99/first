using System;
class Program 
{
    static void Main (string [] args)
    {
        int sum = 0;
        
        Console.Write("Please enter numbers count: ");
        int count = int.Parse(Console.ReadLine());
        
        for (int i=0; i<count; i++)
        {
            Console.Write("Please enter {0} number: ", i+1);
            sum += int.Parse(Console.ReadLine());
        }
        Console.WriteLine("The sum is {0}.", sum);
    }
}
