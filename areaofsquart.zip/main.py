import math 

def square1(a):
    return a*a, 4*a, a*math.sqrt(2)
    
side = 2
    
area = square1(side)[0]
perimeter = square1(side)[1]
diagonal = square1(side)[2]

print ("area = ", area)
print ("perimeter = ", perimeter)
print ("diagonal= ", round(diagonal,2))

#nayti area esli izvestni koordinaty dvuh tochek
def square2(xa, ya, xb, yb):
    a = math.sqrt( (xb-xa)^2 + (yb-ya)^2 )
    values = square1(a)
    return values
    
sq2 = square2( 2,2, 3,2 )
print ("---------------")
print ("area = ", sq2[0])
print ("perimeter = ", sq2[1])
print ("diagonal= ", round(sq2[2],2) )
