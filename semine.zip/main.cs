/******************************************************************************
SE - grading system v. 1.0

*******************************************************************************/
using System;
using System.Collections.Generic;
class HelloWorld
{

  public class Grading
  {
    public string mark;
    public int subjectId;
    public int studentId;
    public int teacherId;
  }

  public class Subject
  {
    public int subjectId;
    public string subjectName;
  }

  public class Student
  {
    public string name;
    public int studentId;
    public void getGrades (int subId)
    {
      Console.WriteLine (" ... to be impelemented ...");
    }

  }

  public class Teacher
  {
    public string name;
    public int teacherId;
    public void givesGrades (int studId, int subId, string m, int teachId, Grading grade)
    {
      grade.studentId = studId;
      grade.subjectId = subId;
      grade.teacherId = teachId;
      grade.mark = m;
    }
  }

  public static string getStudent (List<Student>lst, int id)
  {
    string stName = "";

    for (int i = 0; i < lst.Count; i++)
      {
	if (lst[i].studentId == id)
	  {
	    stName = lst[i].name;
	    break;
	  }
      }
    return stName;
  }

  public static string getTeacher (List<Teacher>lst, int id)
  {
    string tchName = null;

    for (int i = 0; i < lst.Count; i++)
      {
	if (lst[i].teacherId == id)
	  {
	    tchName = lst[i].name;
	    break;
	  }
      }
    return tchName;
  }

  public static string getSubject (List<Subject>lst, int id)
  {
    string subName = null;

    for (int i = 0; i < lst.Count; i++)
    {
	    if (lst[i].subjectId == id)
	    {
	        subName = lst[i].subjectName;
	        break;
	    }
    }
    
    return subName;
  }



  static void Main ()
  {

    //students    
    Student st1 = new Student ();
    st1.name = "Yasemin Okmen";
    st1.studentId = 100;

    Student st2 = new Student ();
    st2.name = "Edanur Levent";
    st2.studentId = 120;

    Student st3 = new Student ();
    st3.name = "Marina Leon";
    st3.studentId = 140;

    List < Student > students = new List < Student > ();

    students.Add (st1);
    students.Add (st2);
    students.Add (st3);

    //teachers
    Teacher t1 = new Teacher ();
    t1.name = "Joe Pass";
    t1.teacherId = 200;

    Teacher t2 = new Teacher ();
    t2.name = "Alex Met";
    t2.teacherId = 122;
    
    List < Teacher > teachers = new List < Teacher > ();

    teachers.Add (t1);
    teachers.Add (t2);

    //subjects
    Subject sub1 = new Subject ();
    sub1.subjectId = 1;
    sub1.subjectName = "Networks";

    Subject sub2 = new Subject ();
    sub2.subjectId = 2;
    sub2.subjectName = "Programming";
    
    List < Subject > subjects = new List < Subject > ();

    subjects.Add (sub1);
    subjects.Add (sub2);

    //grades
    Grading g1 = new Grading ();
    Grading g2 = new Grading ();
    Grading g3 = new Grading ();
    Grading g4 = new Grading ();
    Grading g5 = new Grading ();
    Grading g6 = new Grading ();

    List < Grading > grades = new List < Grading > ();

    t1.givesGrades (st1.studentId, 1, "A", t1.teacherId, g1);
    t2.givesGrades (st2.studentId, 2, "B", t2.teacherId, g2);
    t1.givesGrades (st3.studentId, 1, "C", t1.teacherId, g3);

    grades.Add (g1);
    grades.Add (g2);
    grades.Add (g3);

    /*for (int i = 0; i < grades.Count; i++)
      {
	Console.WriteLine (grades[i].studentId + " " + grades[i].subjectId +
			   " " + grades[i].mark);
      }

    //Console.WriteLine(st1.studentId + " " + st1.name);
    //Console.WriteLine(g1.subjectId);*/
    
    string chosen = "";
    string stName;
    string subName;
    string tchName;
    
    for (int i = 0; i < grades.Count; i++ )
    {
        if (chosen == ""  || chosen == getStudent(students, grades[i].studentId))
        {
            stName = getStudent(students, grades[i].studentId);
            subName = getSubject(subjects, grades[i].subjectId);
            tchName = getTeacher(teachers, grades[i].teacherId);
            Console.WriteLine("{0}\t{1}\t{2}\t{3}", stName, subName, grades[i].mark, tchName);
        }
    }
    Console.WriteLine("-----------------");
    
    string a = "Networks";
    for (int i = 0; i < grades.Count; i++ )
    {
        if (a == ""  || a == getSubject(subjects, grades[i].subjectId))
        {
            stName = getStudent(students, grades[i].studentId);
            subName = getSubject(subjects, grades[i].subjectId);
            tchName = getTeacher(teachers, grades[i].teacherId);

            Console.WriteLine("{0}\t{1}\t{2}\t{3}", stName, subName, grades[i].mark, tchName);
        }
    }
    
  }
}
