using System;
class Program {
  static void Main() {
    int i=2;
 for (i=2; i<=20; i+=2)
 {
     Console.WriteLine( i );
 }
     Console.ReadLine();
  }
}
