#sama sdelala molodes :)
import math

def cubic1(a):
    return a*a*a, 4*a*a, a*math.sqrt(3)

side = 2

volume = cubic1(side)[0]
area = cubic1(side)[1]
diagonal = cubic1(side)[2]

print ("volume = ", volume)
print ("area = ", area)
print ("diagonal= ", round(diagonal,2))
