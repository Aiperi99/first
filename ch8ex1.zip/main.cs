using System;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("150 to binary {0}.", Convert.ToString(150, 2));
        Console.WriteLine("35 to binary {0}.", Convert.ToString(35, 2));
        Console.WriteLine("43 to binary {0}.", Convert.ToString(43, 2));
        Console.WriteLine("251 to binary {0}.", Convert.ToString(251, 2));
    }
}
