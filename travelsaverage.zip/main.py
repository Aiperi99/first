class Travel:
  def __init__(self, destination, month, grade):
    self.destination = destination
    self.month = month
    self.grade = grade

ai1 = Travel("Rzeszow", 10, 7)
ai2 = Travel("Lviv", 10, 10)
ai3 = Travel("Krakow", 10, 10)
ai4 = Travel("Budapest", 9, 9)
ai5 = Travel("Bratislava", 10, 8)
ai6 = Travel("Vienna", 10, 10)
ai7 = Travel("Prague", 10, 10)

travels = []

travels.append(ai1)
travels.append(ai2)
travels.append(ai3)
travels.append(ai4)
travels.append(ai5)
travels.append(ai6)
travels.append(ai7)

print ("Aiperi travels:")
for t in travels:
    print (t.destination, t.grade)

cont = 0
for a in travels:
    cont+= a.grade
    
print(cont/len(travels))