numbers = [1, 4, 3, -2, 0, 6, 2.5]

the_sum=numbers[0]
for i in range (1,len(numbers)):
        the_sum += numbers[i]
print ("The sum:", the_sum)

count = 0
for a in numbers:
    count += numbers[i]
print ("The average is: ", count/len(numbers))