/****************
SE - Orders in a restaurant
****************/
using System;
using System.Collections.Generic;
class Restaurant
{
    public class Table
    {
        public int tableNo;
        public void ordersMeal (int orderNo, string meal, int amount)
        {
            
        }
        public void paysForMeal (double price,int orderNo)
        {
            
        }
    }
    
    public class Waiter
    {
        public string name;
        public void takesOrder (int orderNo, int tableNo, string meal, int amount)
        {
            
        }
    }
    
    public class Order
    {
        public int date;
        public int orderNo;
        public int tableNo;
        public double price;
        public string paymentStatus;
    }
    
    public class Meal
    {
        public int orderNo;
        public string name;
        public int amount;
        public double price;
    }
    
    static void Main ()
  {

    //tables    
    Table t1 = new Table ();
    t1.tableNo = 1;

    Table t2 = new Table ();
    t2.tableNo = 2;
    
    Table t3 = new Table ();
    t3.tableNo = 3;

    List <Table> tables = new List <Table> ();
    tables.Add (t1);
    tables.Add (t2);
    tables.Add (t3);
    
    //waiters    
    Waiter w1 = new Waiter ();
    w1.wName = "Alex";

    Waiter t2 = new Waiter ();
    w2.wName = "Alisa";
    
    List <Waiter> waiters = new List <Waiter> ();
    waiters.Add (w1);
    waiters.Add (w2);
    
    //orders
    Order ord1 = new Order ();
    ord1.orderNo = null;
    ord1.tableNo = null;
    ord1.paymentStatus = null;
    
    Order ord2 = new Order ();
    ord2.orderNo = null;
    ord2.tableNo = null;
    ord2.paymentStatus = null;
    
    List <Order> orders = new List <Order> ();
    orders.Add (ord1);
    orders.Add (ord2);
    
    //meals
    Meal m1 = new Meal ();
    m1.orderNo = null;
    m1.name = "Soup";
    m1.amount = null;
    m1.price = 15;
    
    Meal m2 = new Meal ();
    m2.orderNo = null;
    m2.name = "Pizza";
    m2.amount = null;
    m2.price = 10;
    
    List <Meal> meals = new List <Meal> ();
    meals.Add (m1);
    meals.Add (m2);
  }
  
}