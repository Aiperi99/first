class Student:
    stuCount = 0

    def __init__(self, name, field):
      self.name = name
      self.field = field
      Student.stuCount += 1
   
    def displayCount(self):
     print ("Total Student %d" % Student.stuCount)

    def displayStudent(self):
      print ("Name : ", self.name,  ", Field: ", self.field)
      
stu1=Student('Aiperi', 'IT')
stu2=Student('Alejandro', 'IT')
stu3=Student('Eda', 'Logistics')


#stu1.displayStudent()
#stu2.displayStudent()

the_list = []

the_list.append(stu1)
the_list.append(stu2)
the_list.append(stu3)


for a in the_list:
    print ("%  10s" "%  10s"   %(a.name, a.field))
    
print ("We have", Student.stuCount, " students")

print (stu1.name)
    
