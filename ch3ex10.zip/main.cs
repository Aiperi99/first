using System;
 
class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int firstNumb = (n / 1000) % 10;
        int secondNumb = (n / 100) % 10;
        int thirdNumb = (n / 10) % 10;
        int fourthNumb = (n % 10);
        
        Console.WriteLine("The sum of the digits is: {0}", firstNumb + secondNumb + thirdNumb + fourthNumb);
        Console.WriteLine("Reversed order: {0}{1}{2}{3}", fourthNumb, thirdNumb, secondNumb, firstNumb);
        Console.WriteLine("Last digit upfront: {0}{1}{2}{3}", fourthNumb, firstNumb, secondNumb, thirdNumb);
        Console.WriteLine("Exchanges the second and the third digits: {0}{1}{2}{3}", firstNumb, thirdNumb, secondNumb, fourthNumb);
    }
}