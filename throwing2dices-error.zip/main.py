#throwing two dices

import random

def throw_the_dice():
    return int (random.random()*6) +1
    
N = 10
outcome =[0,0,0,0,0,0,0,0,0,0,0]
    
for i in range(N):
    dice1= throw_the_dice()
    dice2= throw_the_dice()
    outcome[dice1 + dice2 - 2] +=1
    
    
for i in range(11):
    print (i+2, outcome[i]
    
//nado ispravit