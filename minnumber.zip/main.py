numbers = [1, 4, 3, -2, 0, 6, 2.5]

the_smallest=numbers[0]
for i in range (1,len(numbers)):
    if the_smallest > numbers[i]:
        the_smallest = numbers[i]

print ("The smallest:", the_smallest)
    