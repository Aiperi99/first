using System;
class PerimeterArea
{
    static void Main()
    {
 
        double PI = 3.14;
        Console.WriteLine("Please enter the radius of the circle : ");
        double r = Convert.ToDouble(Console.ReadLine());
        double p = 2 * PI * r;
        Console.WriteLine("Perimeter of Circle : {0}", p);
        double a = PI * r * r;
        Console.WriteLine("Area of Circle : {0}", a);
        Console.ReadKey();
    }
}

