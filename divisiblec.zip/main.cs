using System;
class Divisible
{ 
    static void Main()
    {
        Console.WriteLine ("Please enter the integer number");
        int a = int.Parse(Console.ReadLine());
        
        if (a%7==0 && a%5==0) 
        {
            Console.WriteLine ("Congratulations!! This number is divisible by 5 and 7!!");
        }
        else 
        {
            
            Console.WriteLine ("Oops!! Try one more time!!");
        }
    }
}
    
