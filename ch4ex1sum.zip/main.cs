using System;

class Sum
{
    static void Main()
    {
       Console.WriteLine("Please enter the first integer number:");
       int a = int.Parse(Console.ReadLine());
       Console.WriteLine("Please enter the second integer number:");
       int b = int.Parse(Console.ReadLine());
       Console.WriteLine("Please enter the third integer number:");
       int c = int.Parse(Console.ReadLine());
       Console.WriteLine("The result is: {0}", a+b+c);
    }
}